function NewsFinish(){
    NewsLetter.textContent = news[getRandomInt(0,news.length)];
}

const news = 
    ["Privet Dibio",
    "Privet Kryzhyk",
    "Privet Keb🍌",
    "Privet 💀",
    "Privet Efimza",
    "Privet Gig",
    "Privet Vitas2222222222222222222222222222222222222222222222222222222222222222222",
    "Privet Илья",
    "Privet Bipka",
    "Privet ArtZack",
    "Bipki dimensions!",
    "Bipki 2",
    "Universal Bipki?",
    "The best JoJo part is Battle Tendency",
    "Gig, buy Sekiro",
    "Keb, buy Factorio",
    "Also try Eyescape",
    "The binding of Bipki",
    "Bipki Eternal",
    "Barnaul",
    "Privet Egorsi4ek",
    "2 hours of pain",



    //Vitas22222
    "Vitas22222: I PUSH THE WHOLE CHOCOPIE INTO MY MOUTH",
    "Vitas22222: It is a cool game",
    "Vitas22222: ????????????",
    "Vitas22222: А что смешного?",
    "Vitas22222: This is done according to the guides",
    "Vitas22222: Bipki",
    "••• Vitas2222 typing...",
    "Vitas22222: this is kind of funny xdd",
    "Vitas22222: HOW MUCH OF YOU ARE PISSING ME OUT",
    "Vitas22222: YA ekspert zdravogo smysla",
    "Vitas22222: There seems to be a deep plot here",

    "Ligime",
    "One potricule produces 0.1 Bipki, thats everything we know about them",
    "Bipki are extremely powerful and useful, aaaaaaand you can't make em...                                                                              ...but potricules can!",
    "Fishy game",
    "MOAR Bipki",
    "Potricule  ---> Bipki",
    "In next update you'll be able to take Bipki on your wallet!!!                                                                              maybe",
    "Privet Kirr12",
    "Privet KiloProst",
    "Incrementals are cool",
    "ツ",
    "1e308",
    "0.1 + 0.2 = 0.3000000000004",
    "Also try Planet Pixel",
    "🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒🥒",
    "Born too late to explore the Earth, too early to explore the galaxy, but just in time to buy potricules",
    "What will happen on Bipki overdose?",
    "Jpgerge > Jokerge",
    "Pepe became green because of Bipki",
    "Harder than Dark souls",
    "Thanks for playing",
    "Guess the game:❤️🔪  💙💛💚💜🧡",
    "Ало Бипки? Да да бизнес",
    "Keep Bipking",
    " 3 ↑ ↑ ↑ 3",
    "Web design is my passion",
    "https://corndogoncorndog.com",
    "https://ihasabucket.com",
    "Nujabes",
    "Bipki)))",
    "Potricule(((",
    "Хорошие новости (Good news!!!)",
    "Плохие новости (Sadge)",
    "Potricules have sort of hive mind, they are producing Bipki synchronously",
    "А там Бипки",
    "If you reading this close this tab NOW, if you don't do this your heart stop in 10 seconds"


]





NewsFinish();
setInterval(NewsFinish, 40000);